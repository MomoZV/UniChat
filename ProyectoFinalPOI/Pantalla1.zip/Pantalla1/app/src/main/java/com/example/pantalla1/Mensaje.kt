package com.example.pantalla1

import com.google.firebase.database.Exclude

class Mensaje (
    var id:String="",
    var contenido:String="",
    var de:String="",
    val timeStamp: Any?=null

){
    @Exclude
    var esMio:Boolean = false
}


class Tarea(
    val titulo:String,
    val puntos: Int
)
class Alumno(
    val nombre: String,
val alumnos:List<Alumno>
)
class Materia(
    val nombre: String,
    val alumnos: List<Alumno>
)
class Carrera(
    val nombre:String,
    val materias: List<Materia>
)