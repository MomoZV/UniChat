package com.example.pantalla1

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.pantalla1.adaptadores.ChatAdaptador
import com.example.pantalla1.adaptadores.NuevoAdaptador
import com.google.firebase.database.FirebaseDatabase

class chatActivity : AppCompatActivity() {
    private val chatAdaptador = NuevoAdaptador()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        val apellido = intent.getStringExtra("apellido")
        val edad=intent.getIntExtra("edad", 18)
        Toast.makeText(this,"Hola:$apellido", Toast.LENGTH_SHORT).show()

        val rvMensajes = findViewById<RecyclerView>(R.id.rvChat)
        rvMensajes.adapter = chatAdaptador
    }

}