package com.example.pantalla1.adaptadores

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pantalla1.R


class NuevoAdaptador :
            RecyclerView.Adapter<NuevoAdaptador.ViewHolder>() {

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val textView: TextView

            init {
                // Define click listener for the ViewHolder's View.
                textView = view.findViewById(R.id.rvChat)
            }
        }
    override fun getItemCount(): Int {
       return 5
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val miView = LayoutInflater.from(parent.context)
                .inflate(R.layout.messages,parent,false)
        return NuevoAdaptador.ViewHolder(miView)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tvNombre = holder.itemView.findViewById<TextView>(R.id.tvNombre)
        val tvMensaje = holder.itemView.findViewById<TextView>(R.id.tvMensaje)
        val tvHora = holder.itemView.findViewById<TextView>(R.id.tvHora)
        tvNombre.text = when (position) {
            0 -> "A"
            1 -> "B"
            2 -> "C"
            3 -> "D"
            else -> "ZZZZ"
        }

    }
}

