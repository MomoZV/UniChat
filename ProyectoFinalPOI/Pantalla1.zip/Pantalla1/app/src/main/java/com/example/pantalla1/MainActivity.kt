package com.example.pantalla1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.iniciarsesion)
        val btnIniciar = findViewById<Button>(R.id.btnIniciar)
        btnIniciar.setOnClickListener{
            val miIntent = Intent(this, chatActivity::class.java)
            miIntent.putExtra("apellido","Martinez")
            miIntent.putExtra("edad",26)
            startActivity(miIntent)
        }
    }
}